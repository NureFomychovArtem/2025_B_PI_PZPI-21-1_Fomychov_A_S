﻿using Android.App;
using Android.Runtime;

namespace TravelMate
{
    [Application(UsesCleartextTraffic = true)]
    [MetaData("com.google.android.maps.v2.API_KEY",
            Value = "AIzaSyDFbB9UAg55Hh2IRZsTMAEtP8pyZ2MybJA")]
    public class MainApplication : MauiApplication
    {
        public MainApplication(IntPtr handle, JniHandleOwnership ownership)
            : base(handle, ownership)
        {
        }

        protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
    }
}
