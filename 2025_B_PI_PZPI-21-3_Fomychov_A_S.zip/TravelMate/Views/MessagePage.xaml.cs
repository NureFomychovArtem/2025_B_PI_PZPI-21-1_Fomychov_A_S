using TravelMate.ViewModels;

namespace TravelMate;

public partial class MessagePage : ContentPage
{
	public MessagePage(MessageViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        if (BindingContext is BaseViewModel vm)
        {
            await vm.OnAppearing();
        }
    }
}