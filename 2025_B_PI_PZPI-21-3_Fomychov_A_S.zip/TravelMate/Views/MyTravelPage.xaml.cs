using Maui.GoogleMaps;
using TravelMate.Models.DTO;
using TravelMate.ViewModels;

namespace TravelMate;

public partial class MyTravelPage : ContentPage
{
	public MyTravelPage(MyTravelViewModel viewModel)
	{
		InitializeComponent();
        BindingContext = viewModel;
    }


    protected override async void OnAppearing()
    {
        base.OnAppearing();

        if (BindingContext is BaseViewModel vm)
        {
            await vm.OnAppearing();
        }
    }

    private async void TravelCard_Loaded(object sender, EventArgs e)
    {
        if (sender is Frame frame && frame.BindingContext is TravelDTO travel && travel.RoutePoints.Any())
        {
            var map = new Maui.GoogleMaps.Map
            {
                HeightRequest = 150,
                WidthRequest = frame.Width - 20,
                VerticalOptions = LayoutOptions.Start,
                HorizontalOptions = LayoutOptions.FillAndExpand
            };

            map.Pins.Clear();
            map.Polylines.Clear();

            foreach (var point in travel.RoutePoints.OrderBy(p => p.Order))
            {
                var position = new Position(point.Latitude, point.Longitude);
                var pin = new Pin
                {
                    Label = point.Name,
                    Address = point.Description,
                    Position = position,
                    Type = PinType.Place
                };
                map.Pins.Add(pin);
            }

            if (travel.RoutePoints.Count > 1)
            {
                var polyline = new Polyline
                {
                    StrokeColor = Colors.Blue,
                    StrokeWidth = 5f
                };

                foreach (var point in travel.RoutePoints.OrderBy(p => p.Order))
                {
                    polyline.Positions.Add(new Position(point.Latitude, point.Longitude));
                }

                map.Polylines.Add(polyline);
            }

            var firstPoint = travel.RoutePoints.First();
            var mapSpan = MapSpan.FromCenterAndRadius(
                new Position(firstPoint.Latitude, firstPoint.Longitude),
                Distance.FromKilometers(5));
            map.MoveToRegion(mapSpan);

            if (frame.Content is Grid grid)
            {
                var mapContainer = grid.Children.FirstOrDefault(c => c is VerticalStackLayout vsl && vsl.ClassId == "MapContainer");
                if (mapContainer == null)
                {
                    mapContainer = grid.Children.OfType<VerticalStackLayout>().FirstOrDefault();
                }
                if (mapContainer is Layout layout)
                {
                    layout.Children.Clear();
                    layout.Children.Add(map);
                }
            }
        }
    }
}