using Maui.GoogleMaps;
using TravelMate.ViewModels;

namespace TravelMate;

public partial class StatisticPage : ContentPage
{
	public StatisticPage(StatisticsViewModel viewModel)
	{
		InitializeComponent();
        BindingContext = viewModel;
        viewModel.TravelLoaded += ViewModel_TravelLoaded;
    }

    protected override void OnNavigatedTo(NavigatedToEventArgs args)
    {
        base.OnNavigatedTo(args);
    }

    int count = 0;

    private async void ViewModel_TravelLoaded(object sender, EventArgs e)
    {
        base.OnAppearing();

        var viewModel = BindingContext as StatisticsViewModel;

        if (viewModel?.Statistics?.RoutePoints != null && viewModel.Statistics.RoutePoints.Any())
        {
            mymap.Polylines.Clear();

            var polyline = new Polyline
            {
                StrokeColor = Colors.Blue,
                StrokeWidth = 5f
            };

            foreach (var point in viewModel.Statistics.RoutePoints.OrderBy(p => p.Timestamp))
            {
                polyline.Positions.Add(new Maui.GoogleMaps.Position(point.Latitude, point.Longitude));
            }

            mymap.Polylines.Add(polyline);

            var firstPoint = viewModel.Statistics.RoutePoints.First();
            var mapSpan = MapSpan.FromCenterAndRadius(
                new Maui.GoogleMaps.Position(firstPoint.Latitude, firstPoint.Longitude),
                Distance.FromKilometers(5));

            mymap.MoveToRegion(mapSpan);
        }
    }
}