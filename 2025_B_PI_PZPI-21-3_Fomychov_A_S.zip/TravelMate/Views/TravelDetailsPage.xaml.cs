﻿using Maui.GoogleMaps;
using TravelMate.ViewModels;

namespace TravelMate;

public partial class TravelDetailsPage : ContentPage
{
	public TravelDetailsPage(TravelDetailsViewModel travelDetailsViewModel)
	{
        InitializeComponent();
        BindingContext = travelDetailsViewModel;
        travelDetailsViewModel.TravelLoaded += ViewModel_TravelLoaded;
    }

    protected override void OnNavigatedTo(NavigatedToEventArgs args)
    {
        base.OnNavigatedTo(args);
    }

    int count = 0;

    private async void ViewModel_TravelLoaded(object sender, EventArgs e)
    {
        base.OnAppearing();

        var viewModel = BindingContext as TravelDetailsViewModel;

        if (viewModel?.Travel?.RoutePoints != null && viewModel.Travel.RoutePoints.Any())
        {
            mymap.Pins.Clear();
            mymap.Polylines.Clear();

            foreach (var point in viewModel.Travel.RoutePoints.OrderBy(p => p.Order))
            {
                var location = new Maui.GoogleMaps.Position(point.Latitude, point.Longitude);
                var pin = new Pin
                {
                    Label = point.Name,
                    Address = point.Description,
                    Position = location,
                    Type = PinType.Place,
                };
                mymap.Pins.Add(pin);
            }

            if (viewModel.Travel.RoutePoints.Count > 1)
            {
                var polyline = new Polyline
                {
                    StrokeColor = Colors.Blue,
                    StrokeWidth = 5f
                };

                foreach (var point in viewModel.Travel.RoutePoints.OrderBy(p => p.Order))
                {
                    polyline.Positions.Add(new Position(point.Latitude, point.Longitude));
                }

                mymap.Polylines.Add(polyline);
            }

            var firstPoint = viewModel.Travel.RoutePoints.First();
            var mapSpan = MapSpan.FromCenterAndRadius(
                new Maui.GoogleMaps.Position(firstPoint.Latitude, firstPoint.Longitude),
                Distance.FromKilometers(5));

            mymap.MoveToRegion(mapSpan);
        }

        var permission = await CheckAndRequestLocationPermission();
        if (permission == PermissionStatus.Granted)
        {
            try
            {
                var location = await Geolocation.Default.GetLocationAsync();

                if (location != null)
                {
                    var myposition = new Maui.GoogleMaps.Position(location.Latitude, location.Longitude);

                    var userPin = new Pin()
                    {
                        Label = "Ви тут",
                        Position = myposition,
                        Type = PinType.SavedPin
                    };

                    mymap.Pins.Add(userPin);
                }
            }
            catch (FeatureNotEnabledException)
            {
                await DisplayAlert("Помилка", "Служби локації вимкнено. Увімкніть їх у налаштуваннях пристрою.", "OK");
            }
        }

    }

    async Task<PermissionStatus> CheckAndRequestLocationPermission()
    {
        PermissionStatus status = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();

        if (status == PermissionStatus.Granted)
            return status;

        if (status == PermissionStatus.Denied && DeviceInfo.Platform == DevicePlatform.iOS)
        {
            // Prompt the user to turn on in settings
            // On iOS once a permission has been denied it may not be requested again from the application
            return status;
        }

        if (Permissions.ShouldShowRationale<Permissions.LocationWhenInUse>())
        {
            // Prompt the user with additional information as to why the permission is needed
        }

        status = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();

        return status;
    }
}