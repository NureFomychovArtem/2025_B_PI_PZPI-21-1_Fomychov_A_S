using Maui.GoogleMaps;
using TravelMate.Models.DTO;
using TravelMate.ViewModels;

namespace TravelMate;

public partial class AddTravelPage : ContentPage
{
    public AddTravelPage(AddTravelViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
        mymap.MapClicked += OnMapClicked;
    }

    private void OnClearMapClicked(object sender, EventArgs e)
    {
        mymap.Pins.Clear();

        if (BindingContext is AddTravelViewModel vm)
        {
            vm.RoutePoints.Clear();
        }
    }

    private async void OnMapClicked(object sender, MapClickedEventArgs e)
    {
        int index = mymap.Pins.Count + 1;

        string name = await DisplayPromptAsync("���� ����� ��������", "������ ����� �����:",
                                           placeholder: $"Point {index}", maxLength: 100);
        if (string.IsNullOrWhiteSpace(name)) return;

        string description = await DisplayPromptAsync("���� �����", "������ ����:",
                                                      placeholder: $"Description for Point {index}", maxLength: 250);
        if (string.IsNullOrWhiteSpace(description)) return;


        var pin = new Pin
        {
            Label = name,
            Position = e.Point
        };
        mymap.Pins.Add(pin);

        if (BindingContext is AddTravelViewModel vm)
        {
            vm.RoutePoints.Add(new CreateTravelLocationPointDTO
            {
                Latitude = e.Point.Latitude,
                Longitude = e.Point.Longitude,
                Name = name,
                Description = description,
                Order = index
            });
        }
    }

    //async Task<PermissionStatus> CheckAndRequestLocationPermission()
    //{
    //    PermissionStatus status = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();

    //    if (status == PermissionStatus.Granted)
    //        return status;

    //    if (status == PermissionStatus.Denied && DeviceInfo.Platform == DevicePlatform.iOS)
    //    {
    //        // Prompt the user to turn on in settings
    //        // On iOS once a permission has been denied it may not be requested again from the application
    //        return status;
    //    }

    //    if (Permissions.ShouldShowRationale<Permissions.LocationWhenInUse>())
    //    {
    //        // Prompt the user with additional information as to why the permission is needed
    //    }

    //    status = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();

    //    return status;
    //}
}