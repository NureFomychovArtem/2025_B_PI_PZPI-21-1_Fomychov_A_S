using TravelMate.ViewModels;

namespace TravelMate;

public partial class ParticipationPage : ContentPage
{
	public ParticipationPage(ParticipationViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
    }
}