using TravelMate.ViewModels;

namespace TravelMate;

public partial class LoadingPage : ContentPage
{
	public LoadingPage(LoadingPageViewModel viewModel)
	{
        InitializeComponent();
        BindingContext = viewModel;
    }
}