using CommunityToolkit.Maui.Views;
using Maui.GoogleMaps;

namespace TravelMate;

public partial class SelectCoordinatePopup : Popup
{
    private TaskCompletionSource<Position?> _tcs = new();

    public SelectCoordinatePopup()
    {
        InitializeComponent();
    }

    public Task<Position?> GetCoordinateAsync()
    {
        return _tcs.Task;
    }

    private void Map_MapClicked(object sender, MapClickedEventArgs e)
    {
        _tcs.TrySetResult(e.Point);
        Close();
    }

    private void Cancel_Clicked(object sender, EventArgs e)
    {
        _tcs.TrySetResult(null);
        Close();
    }
}
