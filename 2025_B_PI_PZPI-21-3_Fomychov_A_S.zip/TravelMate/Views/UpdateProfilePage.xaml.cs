using TravelMate.ViewModels;

namespace TravelMate;

public partial class UpdateProfilePage : ContentPage
{
	public UpdateProfilePage(UpdateProfileViewModel updateProfileViewModel)
	{
		InitializeComponent();
		BindingContext = updateProfileViewModel;
    }

    protected override void OnNavigatedTo(NavigatedToEventArgs args)
    {
        base.OnNavigatedTo(args);
    }
}