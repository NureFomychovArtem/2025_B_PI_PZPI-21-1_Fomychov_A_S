using TravelMate.ViewModels;

namespace TravelMate;

public partial class ChatPage : ContentPage
{
	public ChatPage(ChatViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
    }

    private async void OnSendMessageClicked(object sender, EventArgs e)
    {
        var text = MessageEntry.Text?.Trim();
        if (!string.IsNullOrWhiteSpace(text))
        {
            var viewModel = BindingContext as ChatViewModel;

            await viewModel.SendMessage(text);
            MessageEntry.Text = string.Empty;
        }
    }

}