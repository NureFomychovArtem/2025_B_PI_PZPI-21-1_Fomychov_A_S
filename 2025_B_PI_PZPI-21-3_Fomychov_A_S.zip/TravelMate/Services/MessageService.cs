﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Diagnostics;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using TravelMate.Enums;
using TravelMate.Models.DTO;
using static Android.Provider.ContactsContract;

namespace TravelMate.Services
{
    public class MessageService
    {
        private readonly LocalDatabaseService _localDb;
        HttpClient _httpClient;
        public static string BaseAddress = DeviceInfo.Platform == DevicePlatform.Android ? "http://192.168.0.101:8080" : "http://localhost:8080";

        public MessageService(LocalDatabaseService localDatabaseService,
            TrackingService trackingService)
        {
            _httpClient = new() { BaseAddress = new Uri(BaseAddress) };
            _localDb = localDatabaseService;
        }

        public async Task<List<TravelChatDTO>> GetChats()
        {
            var participations = await App.ParticipationService.GetMyParticipations();

            var joinedTravelIds = participations
                .Where(p => p.Status == ParticipationStatus.Accepted)
                .Select(p => p.TravelGroupId)
                .ToList();

            var chats = new List<TravelChatDTO>();
            var travel = new TravelDTO();
            foreach (var travelId in joinedTravelIds)
            {

                travel = await App.TravelService.GetTrevel(travelId);

                if (travel != null)
                {
                    chats.Add(new TravelChatDTO
                    {
                        TravelGroupId = travel.Id,
                        Travel = travel.Title
                    });
                }
            }

            if (chats.Count == 0)
            {
                throw new Exception("No chats found for the user.");
            }

            return chats;
        }

        public async Task<List<MessageDTO>> GetMessages(Guid travelGroupId)
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    return null;
                }

                var request = new HttpRequestMessage(HttpMethod.Get, $"api/messages/{travelGroupId}");
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }

                var json = await response.Content.ReadAsStringAsync();
                var result = System.Text.Json.JsonSerializer.Deserialize<PagedResponse<MessageDTO>>(json, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                var messages = result.Items ?? new List<MessageDTO>();

                string fileName;
                foreach (var item in messages)
                {
                    fileName = Path.GetFileName(item.AvatarUrl);
                    item.AvatarUrl = $"http://192.168.0.101:8080/api/avatars/{fileName}";
                }
                return messages;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to retrieve data: {ex.Message}");
            }
        }

        public async Task<bool> SendMessage(CreateMessageDTO message)
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    return false;
                }
                var request = new HttpRequestMessage(HttpMethod.Post, $"api/messages")
                {
                    Content = JsonContent.Create(message)
                }; 
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                
                
                var response = await _httpClient.SendAsync(request);
                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    Debug.WriteLine($"[ERROR] Status: {(int)response.StatusCode} {response.ReasonPhrase}");
                    Debug.WriteLine($"[ERROR] Content: {errorContent}");

                    try
                    {
                        var errorObj = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, string>>(errorContent);
                        if (errorObj != null && errorObj.TryGetValue("message", out var errorMessage))
                        {
                            Debug.WriteLine($"[ERROR MESSAGE] {errorMessage}");
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"[ERROR] Failed to parse error content: {ex.Message}");
                        return false;
                    }
                }
                
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[ERROR] Failed to join travel: {ex.Message}");
                return false;
            }
        }
    }
}
