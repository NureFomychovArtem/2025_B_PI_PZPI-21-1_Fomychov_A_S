﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using TravelMate.Models;
using TravelMate.Models.DTO;

namespace TravelMate.Services
{
    public class UserService
    {
        private readonly LocalDatabaseService _localDb;
        HttpClient _httpClient;
        public static string BaseAddress = DeviceInfo.Platform == DevicePlatform.Android ? "http://192.168.0.101:8080" : "http://localhost:8080";
        public string StatusMessage;
        public UserService(LocalDatabaseService localDatabaseService)
        {
            _httpClient = new() { BaseAddress = new Uri(BaseAddress) };
            _localDb = localDatabaseService;
        }

        public async Task<User?> GetProfileAsync()
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    return null;
                }

                var request = new HttpRequestMessage(HttpMethod.Get, "api/users/profile");
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }

                var json = await response.Content.ReadAsStringAsync();
                var profile = System.Text.Json.JsonSerializer.Deserialize<User>(json, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                var fileName = Path.GetFileName(profile.AvatarUrl);
                if (fileName != null)
                {
                    profile.AvatarUrl = $"http://192.168.0.101:8080/api/avatars/{fileName}?v={Guid.NewGuid()}";
                }
                else
                {
                    profile.AvatarUrl = "default_user.png";
                }
                if (profile is not null)
                    _localDb.SaveUser(profile);
                
                return profile;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка при отриманні профілю: {ex.Message}");
                return null;
            }
        }
        public async Task<ImageSource> GetAvatarByFileName(string fileName)
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    return null;
                }

                var request = new HttpRequestMessage(HttpMethod.Get, $"api/avatars/{fileName}");
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.SendAsync(request);
                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }

                var imageBytes = await response.Content.ReadAsByteArrayAsync();
                return ImageSource.FromStream(() => new MemoryStream(imageBytes));

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка при отриманні аватару: {ex.Message}");
                return null;
            }
        }
        public async Task<bool> UpdateProfileAsync(Guid id, UpdateUserDTO updateUser)
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    throw new Exception($"Користувач не авторизований");

                }

                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-ddTHH:mm:ss.fffZ",
                    ContractResolver = new CamelCasePropertyNamesContractResolver()
                };

                var json = JsonConvert.SerializeObject(updateUser, settings);

                var request = new HttpRequestMessage(HttpMethod.Put, $"api/users/{id}")
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };

                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.SendAsync(request);
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                throw new Exception($"Помилка при оновленні профілю: {ex.Message}");
            }
        }
        public async Task<bool> UploadAvatarAsync(Stream imageStream, string fileName)
        {
            var token = await SecureStorage.GetAsync("auth_token");
            if (string.IsNullOrEmpty(token))
                return false;

            var content = new MultipartFormDataContent();
            var streamContent = new StreamContent(imageStream);
            streamContent.Headers.ContentType = new MediaTypeHeaderValue("image/jpeg");

            content.Add(streamContent, "file", fileName);

            var request = new HttpRequestMessage(HttpMethod.Post, "api/avatars")
            {
                Content = content
            };
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.SendAsync(request);
            return response.IsSuccessStatusCode;
        }
        public async Task<bool> LogoutAsync()
        {
            try
            {
                return _localDb.DeleteUser();
            }
            catch (Exception ex)
            {
                throw new Exception($"Помилка при виході: {ex.Message}");
            }
        }
    }
}
