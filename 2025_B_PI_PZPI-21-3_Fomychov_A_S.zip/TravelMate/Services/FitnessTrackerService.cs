﻿using Plugin.BLE;
using Plugin.BLE.Abstractions.Contracts;
using Plugin.BLE.Abstractions.EventArgs;

namespace TravelMate.Services
{
    public class FitnessTrackerService
    {
        private readonly IAdapter _adapter;
        private IDevice _device;
        private ICharacteristic _heartRateCharacteristic;

        public event Action<int> HeartRateReceived;

        public FitnessTrackerService()
        {
            _adapter = CrossBluetoothLE.Current.Adapter;
        }

        public async Task ConnectToMiBandAsync()
        {
            _device = null;

            _adapter.DeviceDiscovered += OnDeviceDiscovered;

            await _adapter.StartScanningForDevicesAsync();

            if (_device != null)
            {
                await _adapter.StopScanningForDevicesAsync();

                await _adapter.ConnectToDeviceAsync(_device);

                var heartRateService = await _device.GetServiceAsync(Guid.Parse("0000180D-0000-1000-8000-00805f9b34fb"));
                _heartRateCharacteristic = await heartRateService.GetCharacteristicAsync(Guid.Parse("00002A37-0000-1000-8000-00805f9b34fb"));

                if (_heartRateCharacteristic.CanUpdate)
                {
                    _heartRateCharacteristic.ValueUpdated += (s, e) =>
                    {
                        var data = e.Characteristic.Value;
                        if (data.Length > 1)
                        {
                            int heartRate = data[1];
                            HeartRateReceived?.Invoke(heartRate);
                        }
                    };

                    await _heartRateCharacteristic.StartUpdatesAsync();
                }
            }
            else
            {
                throw new Exception("Mi Band device not found.");
            }

            _adapter.DeviceDiscovered -= OnDeviceDiscovered;
        }

        private void OnDeviceDiscovered(object sender, DeviceEventArgs e)
        {
            if (e.Device.Name?.Contains("Mi Band") == true)
            {
                _device = e.Device;
            }
        }
    }
}
