﻿using System.Net.Http.Json;
using System.Text.Json;
using TravelMate.Models.DTO;

namespace TravelMate.Services
{
    public class AuthService
    {
        HttpClient _httpClient;
        public static string BaseAddress = DeviceInfo.Platform == DevicePlatform.Android ? "http://192.168.0.101:8080" : "http://localhost:8080";
        public string StatusMessage;
        public AuthService()
        {
            _httpClient = new() { BaseAddress = new Uri(BaseAddress) };
        }

        public async Task<string> LoginAsync(LoginDTO dto)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync("api/auth/login", dto);

                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var tokenObj = JsonSerializer.Deserialize<TokenResponse>(json, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });
                    return tokenObj.Token;
                }

                throw new Exception("Invalid login credentials");
            }
            catch (Exception ex)
            {
                StatusMessage = $"Login failed: {ex.Message}";
                return null;

            }
        }

        public async Task RegistrationAsync(RegistrationDTO dto)
        {
            var response = await _httpClient.PostAsJsonAsync("api/registration/register", dto);

            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                throw new Exception($"Registration failed: {errorContent}");
            }
        }
    }
}
