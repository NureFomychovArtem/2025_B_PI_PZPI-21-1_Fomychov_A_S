﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Diagnostics;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using TravelMate.Enums;
using TravelMate.Models.DTO;

namespace TravelMate.Services
{
    public class TravelService
    {
        private readonly LocalDatabaseService _localDb;
        private readonly TrackingService _trackingService;
        HttpClient _httpClient;
        public static string BaseAddress = DeviceInfo.Platform == DevicePlatform.Android ? "http://192.168.0.101:8080" : "http://localhost:8080";

        public TravelService(LocalDatabaseService localDatabaseService, 
            TrackingService trackingService)
        {
            _httpClient = new() { BaseAddress = new Uri(BaseAddress) };
            _localDb = localDatabaseService;
            _trackingService = trackingService;
        }

        public async Task<List<TravelDTO>> GetTrevels()
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    return null;
                }

                var request = new HttpRequestMessage(HttpMethod.Get, "api/travel-groups");
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }

                var json = await response.Content.ReadAsStringAsync();
                var travels = System.Text.Json.JsonSerializer.Deserialize<List<TravelDTO>>(json, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                SaveTravelsToLocalDatabase(travels);

                return travels;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to retrieve data: {ex.Message}");
            }
        }

        public async Task<TravelDTO> GetTrevel(Guid id)
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    return GetTravelFromLocalDatabase(id);
                }

                var request = new HttpRequestMessage(HttpMethod.Get, $"api/travel-groups/{id.ToString()}");
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    return GetTravelFromLocalDatabase(id);
                }

                var json = await response.Content.ReadAsStringAsync();
                var travel = System.Text.Json.JsonSerializer.Deserialize<TravelDTO>(json, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                if (travel is null)
                {
                    _localDb.StatusMessage = $"Помилка отримання даних про подорож";
                    return GetTravelFromLocalDatabase(id);
                }

                return travel;
            }
            catch(Exception ex)
            {
                _localDb.StatusMessage = $"Помилка отримання даних про подорож: {ex.Message}";
                return null;
            }
        }

        public async Task<bool> AddTravelAsync(CreateTravelDTO createTravelDTO)
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    throw new Exception($"Користувач не авторизований");

                }

                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-ddTHH:mm:ss.fffZ",
                    ContractResolver = new CamelCasePropertyNamesContractResolver()
                };

                var json = JsonConvert.SerializeObject(createTravelDTO, settings);

                var request = new HttpRequestMessage(HttpMethod.Post, $"api/travel-groups")
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };

                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.SendAsync(request);
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                _localDb.StatusMessage = "Failed to add travel";
                return false;
            }
        }

        public async Task<bool> ChangeStatusTravel(StatusTravelDTO dto)
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    return false;
                }

                var request = new HttpRequestMessage(HttpMethod.Patch, $"api/travel-groups/{dto.TravelGroupId.ToString()}/status")
                {
                    Content = JsonContent.Create(dto)
                };


                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var response = await _httpClient.SendAsync(request);
                if (!response.IsSuccessStatusCode)
                {
                    var errorMessage = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"Error message: {errorMessage}");
                    return false;
                }

                if(dto.Status == TravelGroupStatus.Active)
                    _trackingService.StartTracking(dto.TravelGroupId);

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[ERROR] Failed to leave travel: {ex.Message}");
                return false;
            }
        }


        //public async Task<bool> LeaveTravel(Guid travelId)
        //{
        //    try
        //    {
        //        var token = await SecureStorage.GetAsync("auth_token");
        //        if (string.IsNullOrEmpty(token))
        //        {
        //            return false;
        //        }
        //        var request = new HttpRequestMessage(HttpMethod.Delete, $"api/participation/{travelId}");
        //        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        //        var response = await _httpClient.SendAsync(request);
        //        if (!response.IsSuccessStatusCode)
        //            return false;
        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        Debug.WriteLine($"[ERROR] Failed to leave travel: {ex.Message}");
        //        return false;
        //    }
        //}

        public async Task<TravelDTO> UpdateTravelAsync(UpdateTravelDTO updateTravelDTO)
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    throw new Exception($"Користувач не авторизований");

                }

                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-ddTHH:mm:ss.fffZ",
                    ContractResolver = new CamelCasePropertyNamesContractResolver()
                };

                var json = JsonConvert.SerializeObject(updateTravelDTO, settings);

                var request = new HttpRequestMessage(HttpMethod.Put, $"api/travel-groups/{updateTravelDTO.Id.ToString()}")
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };

                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.SendAsync(request);
                
                if (!response.IsSuccessStatusCode)
                {
                    _localDb.StatusMessage = "Помилка оновлення даних про подорож";
                    return null;
                }

                json = await response.Content.ReadAsStringAsync();
                var travel = System.Text.Json.JsonSerializer.Deserialize<TravelDTO>(json, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                if (travel is null)
                {
                    _localDb.StatusMessage = $"Помилка отримання даних про подорож";
                    return null;
                }
                return travel;
            }
            catch (Exception ex)
            {
                _localDb.StatusMessage = $"Помилка оновлення даних про подорож: {ex.Message}";
                return null;
            }
        }
        
        private async Task SaveTravelsToLocalDatabase(List<TravelDTO> travels)
        {
            if (travels == null || travels.Count == 0)
            {
                return;
            }

            foreach (var travel in travels)
            {
                try
                {
                    if (travel != null)
                        _localDb.SaveTravel(travel);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"[ERROR] Failed to save travels to local database: {ex.Message}");
                }
            }
        }
        private TravelDTO GetTravelFromLocalDatabase(Guid id)
        {
            var travelLocal = _localDb.GetTravelById(id)
                ?? throw new Exception($"Travel with ID ${id} was now found");

            var routePoints = _localDb.GetTravelLocationPointByTravelId(id);
            var participations = _localDb.GetParticipationsByTravelId(id);

            var result = new TravelDTO
            {
                Id = travelLocal.Id,
                Title = travelLocal.Title,
                Description = travelLocal.Description,
                MaxParticipants = travelLocal.MaxParticipants,
                StartTime = travelLocal.StartTime,
                Status = travelLocal.Status,
                Difficulty = travelLocal.Difficulty,
                EndTime = travelLocal.EndTime,
                GroupParticipationDtos = new List<GroupParticipationDTO>()
            };

            foreach (var point in routePoints)
            {
                result.RoutePoints.Add(new TravelLocationPointDTO
                {
                    Id = point.Id,
                    Latitude = point.Latitude,
                    Longitude = point.Longitude,
                    Name = point.Name,
                    Description = point.Description,
                    Order = point.Order
                });
            }

            foreach (var participation in participations)
            {
                result.GroupParticipationDtos.Add(new GroupParticipationDTO
                {
                    Id = participation.Id,
                    UserId = participation.UserId,
                    Username = "unknown",
                    Email = "unknown",
                    IsAdmin = participation.IsAdmin,
                    Status = participation.Status,
                    JoinedAt = participation.JoinedAt,
                });
            }

            return result;
        }
    }
}

 