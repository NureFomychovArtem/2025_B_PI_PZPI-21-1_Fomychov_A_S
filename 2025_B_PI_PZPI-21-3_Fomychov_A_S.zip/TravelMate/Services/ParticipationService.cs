﻿using System.Diagnostics;
using System.Net.Http.Headers;
using System.Text.Json;
using TravelMate.Models;
using TravelMate.Models.DTO;

namespace TravelMate.Services
{
    public class ParticipationService
    {
        private readonly LocalDatabaseService _localDb;
        HttpClient _httpClient;
        public static string BaseAddress = DeviceInfo.Platform == DevicePlatform.Android ? "http://192.168.0.101:8080" : "http://localhost:8080";

        public ParticipationService(LocalDatabaseService localDatabaseService,
            TrackingService trackingService)
        {
            _httpClient = new() { BaseAddress = new Uri(BaseAddress) };
            _localDb = localDatabaseService;
        }

        public async Task<List<GroupParticipationDTO>> GetParticipationsByTravelId(string travelId)
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token) || string.IsNullOrEmpty(travelId))
                {
                    return null;
                }

                var request = new HttpRequestMessage(HttpMethod.Get, $"api/participation/by-group/{travelId}");
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }

                var json = await response.Content.ReadAsStringAsync();
                var participations = System.Text.Json.JsonSerializer.Deserialize<List<GroupParticipationDTO>>(json, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                SaveParticipationsToLocalDatabase(participations, travelId);

                return participations;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to retrieve data: {ex.Message}");
            }
        }

        public async Task<List<ParticipationDTO>> GetMyParticipations()
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    return null;
                }

                var request = new HttpRequestMessage(HttpMethod.Get, "api/participation/me");
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }

                var json = await response.Content.ReadAsStringAsync();
                var participations = System.Text.Json.JsonSerializer.Deserialize<List<ParticipationDTO>>(json, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                return participations;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to retrieve data: {ex.Message}");
            }
        }

        public async Task<bool> ChangeParticipationStatusAsync(Guid id, string status)
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    Debug.WriteLine("[ERROR] Token is missing.");
                    return false;
                }

                var request = new HttpRequestMessage(
                    HttpMethod.Put,
                    $"api/participation/{id}/status?status={status}");

                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    Debug.WriteLine($"[ERROR] ChangeStatusParticipationAsync failed: {(int)response.StatusCode} - {response.ReasonPhrase}");
                    Debug.WriteLine($"[ERROR CONTENT] {errorContent}");
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[EXCEPTION] {ex.Message}");
                return false;
            }
        }

        public async Task<bool> CreateParticipationAsync(Guid travelId)
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    return false;
                }
                var request = new HttpRequestMessage(HttpMethod.Post, $"api/participation/{travelId.ToString()}");
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var response = await _httpClient.SendAsync(request);
                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    Debug.WriteLine($"[ERROR] Status: {(int)response.StatusCode} {response.ReasonPhrase}");
                    Debug.WriteLine($"[ERROR] Content: {errorContent}");

                    try
                    {
                        var errorObj = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, string>>(errorContent);
                        if (errorObj != null && errorObj.TryGetValue("message", out var message))
                        {
                            Debug.WriteLine($"[ERROR MESSAGE] {message}");
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"[ERROR] Failed to parse error content: {ex.Message}");
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[ERROR] Failed to join travel: {ex.Message}");
                return false;
            }
        }
        public async Task<bool> ConfirmParticipation(Guid id)
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    return false;
                }
                var request = new HttpRequestMessage(HttpMethod.Post, $"api/participation/{id.ToString()}/confirm");
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var response = await _httpClient.SendAsync(request);
                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    Debug.WriteLine($"[ERROR] Status: {(int)response.StatusCode} {response.ReasonPhrase}");
                    Debug.WriteLine($"[ERROR] Content: {errorContent}");

                    try
                    {
                        var errorObj = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, string>>(errorContent);
                        if (errorObj != null && errorObj.TryGetValue("message", out var message))
                        {
                            Debug.WriteLine($"[ERROR MESSAGE] {message}");
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"[ERROR] Failed to parse error content: {ex.Message}");
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[ERROR] Failed to join travel: {ex.Message}");
                return false;
            }
        }
        
        public async Task<TrackingStatistics> GetStatistics(Guid participationId)
        {
            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    return null;
                }
                var request = new HttpRequestMessage(HttpMethod.Get, $"api/statistics/participation/{participationId}");
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var response = await _httpClient.SendAsync(request);
                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                var json = await response.Content.ReadAsStringAsync();
                var statistics = System.Text.Json.JsonSerializer.Deserialize<TrackingStatistics>(json, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
                return statistics;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to retrieve statistics: {ex.Message}");
            }
        }
        private void SaveParticipationsToLocalDatabase(List<GroupParticipationDTO>? participations, string travelId)
        {

            foreach(var participation in participations)
            {

                _localDb.SaveParticipation(new Participation
                {
                    Id = participation.Id,
                    UserId = participation.UserId,
                    TravelId = new Guid(travelId),
                    IsAdmin = participation.IsAdmin,
                    Status = participation.Status,
                    JoinedAt = participation.JoinedAt,
                });
            }
        }


    }
}
