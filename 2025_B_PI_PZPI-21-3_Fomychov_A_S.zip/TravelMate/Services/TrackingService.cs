﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Diagnostics;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using TravelMate.Models;
using TravelMate.Models.DTO;
using TravelMate.Models.DTO.Tracking;
using static Android.Provider.Telephony.Mms;

namespace TravelMate.Services
{
    public class TrackingService
    {
        private readonly LocalDatabaseService _localDb;
        private readonly FitnessTrackerService _fitnesTrackerService;
        HttpClient _httpClient;
        public static string BaseAddress = DeviceInfo.Platform == DevicePlatform.Android ? "http://192.168.0.101:8080" : "http://localhost:8080";

        private CancellationTokenSource _cts;
        private Guid _travelGroupId;

        public TrackingService(LocalDatabaseService localDatabaseService,
            FitnessTrackerService fitnesTrackerService)
        {
            _localDb = localDatabaseService;
            _fitnesTrackerService = fitnesTrackerService;
            _httpClient = new() { BaseAddress = new Uri(BaseAddress) };
        }

        public void StartTracking(Guid travelGroupId)
        {
            _travelGroupId = travelGroupId;
            _cts = new CancellationTokenSource();
            Task.Run(async () => await TrackingLoopAsync(_cts.Token));
        }
        public async Task StopTracking()
        {
            var location = await Geolocation.GetLocationAsync();

            int heartRate = await GetLatestHeartRateFromMiBand();

            var data = new LocalTrackingData
            {
                TravelId = _travelGroupId,
                Latitude = location?.Latitude ?? 0,
                Longitude = location?.Longitude ?? 0,
                HeartRate = heartRate,
                Timestamp = DateTime.UtcNow
            };

            bool sent = await TrySendTrackingDataAsync(data);

            _cts.Cancel();
        }
        private async Task TrackingLoopAsync(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    var location = await Geolocation.GetLocationAsync();

                    int heartRate = await GetLatestHeartRateFromMiBand();

                    var data = new LocalTrackingData
                    {
                        TravelId = _travelGroupId,
                        Latitude = location?.Latitude ?? 0,
                        Longitude = location?.Longitude ?? 0,
                        HeartRate = heartRate,
                        Timestamp = DateTime.UtcNow
                    };

                    bool sent = await TrySendTrackingDataAsync(data);

                    if (!sent)
                        _localDb.SaveTrackingData(data);
                    else
                        await SendCachedDataAsync();

                    if (heartRate < 40 || heartRate > 180)
                        await SendEmergencyCallAsync(data.Latitude, data.Longitude, "HeartRateAnomaly");
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Unable to load tracking data: {ex.Message}");
                    return;
                }

                await Task.Delay(TimeSpan.FromSeconds(30), token); 
            }
        }

        private async Task<bool> TrySendTrackingDataAsync(LocalTrackingData data)
        {
            try
            {
                var dto = new TrackingDataCreateDTO
                {
                    TravelGroupId = data.TravelId,
                    Latitude = data.Latitude,
                    Longitude = data.Longitude,
                    HeartRate = data.HeartRate,
                    Timestamp = data.Timestamp
                };

                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    throw new Exception($"Користувач не авторизований");

                }


                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-ddTHH:mm:ss.fffZ",
                    ContractResolver = new CamelCasePropertyNamesContractResolver()
                };

                var json = JsonConvert.SerializeObject(dto, settings);

                Console.WriteLine("📤 Відправляється JSON:");
                Console.WriteLine(json);

                var request = new HttpRequestMessage(HttpMethod.Post, $"api/tracking")
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };

                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.SendAsync(request);
                Console.WriteLine($"📡 Status: {response.StatusCode} {response.ReasonPhrase}");

                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        private async Task SendCachedDataAsync()
        {
            var cachedData = _localDb.GetAllTrackingData();
            foreach (var data in cachedData)
            {
                bool sent = await TrySendTrackingDataAsync(data);
                if (sent)
                {
                    _localDb.DeleteTrackingData(data.Id);
                }
                else
                {
                    break;
                }
            }
        }

        private async Task<bool> SendEmergencyCallAsync(double latitude, double longitude, string emergencyType)
        {
            var emergencyDto = new EmergencyCallCreateDTO
            {
                TravelGroupId = _travelGroupId,
                Latitude = latitude,
                Longitude = longitude,
                EmergencyType = emergencyType,
                Comment = "Automatically generated emergency due to heart rate anomaly"
            };

            try
            {
                var token = await SecureStorage.GetAsync("auth_token");
                if (string.IsNullOrEmpty(token))
                {
                    throw new Exception($"Користувач не авторизований");

                }

                var request = new HttpRequestMessage(HttpMethod.Post, $"api/tracking")
                {
                    Content = JsonContent.Create(emergencyDto)
                };

                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.SendAsync(request);
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        private async Task<int> GetLatestHeartRateFromMiBand()
        {
            try
            {
                var tcs = new TaskCompletionSource<int>();
                var tracker = new FitnessTrackerService();

                tracker.HeartRateReceived += (rate) =>
                {
                    Console.WriteLine($"Отримано пульс: {rate}");
                    tcs.TrySetResult(rate);
                };

                await tracker.ConnectToMiBandAsync();

                var completedTask = await Task.WhenAny(tcs.Task, Task.Delay(10000));
                if (completedTask == tcs.Task)
                {
                    return tcs.Task.Result;
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine($"Error to scan heart rate: {ex.Message}");
            }

            var random = new Random();

            return random.Next(60, 120);
        }
    }
}
