﻿using SQLite;
using TravelMate.Enums;
using TravelMate.Models;
using TravelMate.Models.DTO;

namespace TravelMate.Services
{
    public class LocalDatabaseService
    {
        SQLiteConnection conn;
        string _dbPath;
        public string StatusMessage;
        int result = 0;

        public LocalDatabaseService(string dbPath)
        {
            _dbPath = dbPath;
            Init();
        }

        
        private void Init()
        {
            if (conn != null)
                return;

            conn = new SQLiteConnection(_dbPath);
            conn.CreateTable<LocalTrackingData>();
            conn.CreateTable<MessageDTO>();
            conn.CreateTable<Participation>();
            conn.CreateTable<Travel>();
            conn.CreateTable<TravelLocationPoint>();
            conn.CreateTable<User>();
            conn.CreateTable<UserLanguage>();
        }

        //Participation Methods
        public List<Participation> GetParticipationsByTravelId(Guid travelId)
        {
            Init();
            return conn.Table<Participation>().Where(x => x.TravelId == travelId).ToList();
        }

        public void SaveParticipation(Participation travel)
        {
            Init();
            conn.InsertOrReplace(travel);
        }

        // Tracking Data Methods
        public void SaveTrackingData(LocalTrackingData data)
        {
            Init();
            conn.Insert(data);
        }
        public List<LocalTrackingData> GetAllTrackingData()
        {
            Init();
            return conn.Table<LocalTrackingData>().ToList();
        }
        public void DeleteTrackingData(Guid id)
        {
            Init();
            conn.Delete<LocalTrackingData>(id);
        }
        
        //Travel Methods
        public void SaveTravel(TravelDTO travel)
        {
            Init();

            var travelEntity = new Travel
            {
                Id = travel.Id,
                Title = travel.Title,
                Description = travel.Description,
                StartTime = travel.StartTime,
                EndTime = travel.EndTime,
                Status = travel.Status,
                Difficulty = travel.Difficulty
            };

            conn.InsertOrReplace(travelEntity);

            foreach (var location in travel.RoutePoints)
            {
                if (location != null)
                {
                    var point = new TravelLocationPoint
                    {
                        Id = location.Id,
                        TravelId = travel.Id,
                        Latitude = location.Latitude,
                        Longitude = location.Longitude,
                        Name = location.Name,
                        Description = location.Description,
                        Order = location.Order
                    };

                    conn.InsertOrReplace(point);
                }
            }

            foreach (var participation in travel.GroupParticipationDtos)
            {
                var participant = new Participation
                {
                    Id = participation.Id,
                    UserId = participation.UserId,
                    TravelId = travel.Id,
                    IsAdmin = participation.IsAdmin,
                    Status = participation.Status,
                    TotalDistanceKm = 0,
                    JoinedAt = participation.JoinedAt,
                    HasJoined = true,
                    RealJoinTime = participation.JoinedAt,
                    LeftAt = null,
                };

                conn.InsertOrReplace(participation);
            }
        }
        public Travel GetTravelById(Guid travelId)
        {
            Init();
            return conn.Table<Travel>().FirstOrDefault(t => t.Id == travelId);
        }
        public List<Travel> GetTravels()
        {
            Init();
            return conn.Table<Travel>().ToList();
        }

        //TravelLocationPoint Methods
        public List<TravelLocationPoint> GetTravelLocationPointByTravelId(Guid travelId)
        {
            Init();
            return conn.Table<TravelLocationPoint>().Where(x => x.TravelId == travelId).ToList();
        }

        //User Methods
        public void SaveUser(User user)
        {
            Init();
            conn.InsertOrReplace(user);
        }
        public bool DeleteUser()
        {
            Init();
            return conn.DeleteAll<User>() > 0;
        }



    }
}
