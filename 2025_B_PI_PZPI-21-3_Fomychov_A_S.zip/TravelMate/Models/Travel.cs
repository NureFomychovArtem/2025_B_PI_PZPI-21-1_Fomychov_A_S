﻿using SQLite;
using TravelMate.Enums;

namespace TravelMate.Models
{
    [Table("travels")]
    public class Travel : BaseEntity
    {
        [NotNull]
        [MaxLength(150)]
        public string Title { get; set; } = null!;
        public string? Description { get; set; }
        public int MaxParticipants { get; set; } = 100;
        [NotNull]
        public DateTime? StartTime { get; set; }
        [NotNull]
        public DateTime? EndTime { get; set; }
        public TravelGroupStatus Status { get; set; } = TravelGroupStatus.Planned;
        public TravelDifficulty Difficulty { get; set; }
    }
}
