﻿using SQLite;

namespace TravelMate.Models
{
    [Table("travelPonts")]
    public class TravelLocationPoint : BaseEntity
    {
        [NotNull]
        public Guid TravelId { get; set; }

        [Ignore]
        public Travel Travel { get; set; } = null!;

        [NotNull]
        public double Latitude { get; set; }

        [NotNull]
        public double Longitude { get; set; }

        public string? Name { get; set; }

        public string? Description { get; set; }

        [NotNull]
        public int Order { get; set; }
    }
} 

