﻿using SQLite;

namespace TravelMate.Models
{
    public abstract class BaseEntity
    {
        [NotNull]
        [MaxLength(32)]
        [PrimaryKey, AutoIncrement]
        public Guid Id { get; set; }
    }
}
