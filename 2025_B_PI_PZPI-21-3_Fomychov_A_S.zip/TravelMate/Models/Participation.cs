﻿using SQLite;
using TravelMate.Enums;

namespace TravelMate.Models
{
    [Table("participation")]
    public class Participation: BaseEntity
    {
        [NotNull]
        public Guid UserId { get; set; }

        [NotNull]
        public Guid TravelId { get; set; }

        public bool IsAdmin { get; set; } = false;

        public ParticipationStatus Status { get; set; } = ParticipationStatus.Pending;

        public double TotalDistanceKm { get; set; } = 0;

        public DateTime JoinedAt { get; set; } = DateTime.UtcNow;

        public bool HasJoined { get; set; } = false;

        public DateTime? RealJoinTime { get; set; }

        public DateTime? LeftAt { get; set; }

        [Ignore]
        public User User { get; set; } = null!;
        [Ignore]
        public Travel Travel { get; set; } = null!;
    }
}
