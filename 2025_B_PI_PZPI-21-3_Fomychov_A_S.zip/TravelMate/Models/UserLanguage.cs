﻿using SQLite;

namespace TravelMate.Models
{
    [Table("userLanguages")]
    public class UserLanguage : BaseEntity
    {
        public Guid UserId { get; set; }

        public string Language { get; set; } = string.Empty;

        public DateTime AddedDate { get; set; } = DateTime.UtcNow;

        [Ignore]
        public User User { get; set; }
    }
}
