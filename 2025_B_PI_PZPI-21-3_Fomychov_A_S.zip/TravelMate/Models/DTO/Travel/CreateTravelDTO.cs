﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using TravelMate.Enums;

namespace TravelMate.Models.DTO
{
    public class CreateTravelDTO
    {
        public string Title { get; set; } = "";
        public string? Description { get; set; } = "";
        public int MaxParticipants { get; set; } = 1;
        public DateTime? StartTime { get; set; } = DateTime.UtcNow;
        public DateTime? EndTime { get; set; } = DateTime.UtcNow.AddDays(1);
        public TravelDifficulty Difficulty { get; set; } = TravelDifficulty.Moderate;
        public List<CreateTravelLocationPointDTO> RoutePoints { get; set; } = new List<CreateTravelLocationPointDTO>();
    }
}
