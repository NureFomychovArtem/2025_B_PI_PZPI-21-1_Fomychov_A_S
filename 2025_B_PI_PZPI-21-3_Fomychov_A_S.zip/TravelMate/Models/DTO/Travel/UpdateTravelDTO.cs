﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelMate.Enums;

namespace TravelMate.Models.DTO
{
    public class UpdateTravelDTO : BaseEntity
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public int MaxParticipants { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public TravelGroupStatus Status { get; set; }
        public TravelDifficulty Difficulty { get; set; }
        public ICollection<TravelLocationPointDTO> RoutePoints { get; set; } = new List<TravelLocationPointDTO>();
    }
}
