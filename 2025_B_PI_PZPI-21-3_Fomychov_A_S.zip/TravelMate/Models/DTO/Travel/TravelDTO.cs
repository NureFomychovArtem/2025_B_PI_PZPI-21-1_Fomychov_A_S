﻿using TravelMate.Enums;

namespace TravelMate.Models.DTO
{
    public class TravelDTO : BaseEntity
    {
        public string Title { get; set; } = "";
        public string? Description { get; set; }
        public int MaxParticipants { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public TravelGroupStatus Status { get; set; }
        public TravelDifficulty Difficulty { get; set; }

        public ICollection<TravelLocationPointDTO> RoutePoints { get; set; } = new List<TravelLocationPointDTO>();
        public ICollection<GroupParticipationDTO> GroupParticipationDtos { get; set; } = new List<GroupParticipationDTO>();
    }
}
