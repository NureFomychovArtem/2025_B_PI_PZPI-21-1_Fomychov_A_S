﻿using TravelMate.Enums;

namespace TravelMate.Models.DTO
{
    public class StatusTravelDTO
    {
        public Guid TravelGroupId { get; set; }
        public TravelGroupStatus Status { get; set; }
    }
}
