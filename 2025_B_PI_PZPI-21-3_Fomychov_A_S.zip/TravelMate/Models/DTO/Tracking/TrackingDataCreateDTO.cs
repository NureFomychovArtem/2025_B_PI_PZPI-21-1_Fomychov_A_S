﻿using System.ComponentModel.DataAnnotations;

namespace TravelMate.Models.DTO
{
    public class TrackingDataCreateDTO
    {
        [Required]
        public Guid TravelGroupId { get; set; }

        [Required]
        public double Latitude { get; set; }

        [Required]
        public double Longitude { get; set; }

        [Required]
        [Range(30, 220, ErrorMessage = "Недопустиме значення пульсу")]
        public int HeartRate { get; set; }

        public DateTime? Timestamp { get; set; } = DateTime.UtcNow;
    }
}
