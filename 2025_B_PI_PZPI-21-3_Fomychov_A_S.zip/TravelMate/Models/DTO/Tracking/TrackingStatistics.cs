﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelMate.Models.DTO
{
    public class TrackingStatistics
    {
        public Guid ParticipationId { get; set; }

        public double DistanceKm { get; set; }

        public TimeSpan TravelDuration { get; set; }

        public double AverageHeartRate { get; set; }
        public int MaxHeartRate { get; set; }
        public int MinHeartRate { get; set; }

        public int TrackingPointsCount { get; set; }

        public List<TrackingPoint> RoutePoints { get; set; } = new();
    }

}
