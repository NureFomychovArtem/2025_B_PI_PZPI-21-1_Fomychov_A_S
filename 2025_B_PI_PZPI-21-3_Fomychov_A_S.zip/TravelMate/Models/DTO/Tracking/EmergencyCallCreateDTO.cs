﻿using System.ComponentModel.DataAnnotations;

namespace TravelMate.Models.DTO.Tracking
{
    public class EmergencyCallCreateDTO
    {
        [Required]
        public Guid TravelGroupId { get; set; }

        [Required]
        public double Latitude { get; set; }

        [Required]
        public double Longitude { get; set; }

        [Required]
        public string EmergencyType { get; set; }

        public string? Comment { get; set; }
    }
}
