﻿namespace TravelMate.Models.DTO
{
    public record RegistrationDTO(string Email, string Username, string Password, string FirstName, string LastName);
}
