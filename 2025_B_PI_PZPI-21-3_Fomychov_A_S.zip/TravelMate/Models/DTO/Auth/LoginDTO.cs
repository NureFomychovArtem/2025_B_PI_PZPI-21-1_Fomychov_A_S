﻿namespace TravelMate.Models.DTO
{
    public record LoginDTO(string EmailOrUsername, string Password);
}
