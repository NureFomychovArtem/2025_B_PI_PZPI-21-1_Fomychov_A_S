﻿namespace TravelMate.Models.DTO
{
    public class TokenResponse
    {
        public string Token { get; set; }
    }
}
