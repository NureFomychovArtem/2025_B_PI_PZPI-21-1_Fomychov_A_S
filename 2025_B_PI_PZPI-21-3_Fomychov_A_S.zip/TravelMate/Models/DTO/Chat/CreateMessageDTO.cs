﻿namespace TravelMate.Models.DTO
{
    public class CreateMessageDTO
    {
        public Guid TravelGroupId { get; set; }
        public string Text { get; set; }
    }
}
