﻿namespace TravelMate.Models.DTO
{
    public class TravelChatDTO
    {
        public Guid TravelGroupId { get; set; }
        public string Travel { get; set; }
    }
}
