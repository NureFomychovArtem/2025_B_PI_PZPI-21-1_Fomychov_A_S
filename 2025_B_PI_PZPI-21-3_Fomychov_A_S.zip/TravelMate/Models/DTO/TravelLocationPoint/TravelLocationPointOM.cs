﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace TravelMate.Models.DTO
{
    public partial class TravelLocationPointOM : ObservableObject
    {
        [ObservableProperty]
        public Guid id;
        [ObservableProperty]
        public double latitude;
        [ObservableProperty]
        public double longitude;
        [ObservableProperty]
        public string name;
        [ObservableProperty]
        public string description;
        [ObservableProperty]
        public int order;
    }
}
