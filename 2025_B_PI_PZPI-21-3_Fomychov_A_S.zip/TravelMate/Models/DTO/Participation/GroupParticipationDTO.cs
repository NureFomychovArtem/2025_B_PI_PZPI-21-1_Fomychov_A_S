﻿using TravelMate.Enums;

namespace TravelMate.Models.DTO
{
    public class GroupParticipationDTO: BaseEntity
    {
        public Guid UserId { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public ParticipationStatus Status { get; set; }
        public bool IsAdmin { get; set; }
        public DateTime JoinedAt { get; set; }
        public bool IsNotAdmin => !IsAdmin;

    }
}
