﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelMate.Enums;

namespace TravelMate.Models.DTO
{
    public class ParticipationDTO : BaseEntity
    {
        public Guid TravelGroupId { get; set; }
        public ParticipationStatus Status { get; set; }
        public bool IsAdmin { get; set; }
        public DateTime JoinedAt { get; set; }
    }
}
