﻿using SQLite;

namespace TravelMate.Models
{
    [Table("users")]
    public class User : BaseEntity
    {
        [NotNull]
        public string Username { get; set; }

        [NotNull]
        public string Email { get; set; }

        [NotNull]
        public string? FirstName { get; set; }

        [NotNull]
        public string? LastName { get; set; }

        public DateTime? DateOfBirth { get; set; }

        public string? AvatarUrl { get; set; }

        public bool IsActive { get; set; } = false;

        public bool IsBanned { get; set; } = false;

        public bool IsSystemAdmin { get; set; } = false;

        public string? PhoneNumber { get; set; }

        public string? City { get; set; }

        public string? Country { get; set; }

        [Ignore]
        public ICollection<UserLanguage> UserLanguages { get; set; } = new List<UserLanguage>();

        public string? Bio { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    }
}
