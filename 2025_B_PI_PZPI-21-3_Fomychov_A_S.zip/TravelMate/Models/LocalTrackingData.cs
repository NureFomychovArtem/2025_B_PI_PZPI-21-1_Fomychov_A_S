﻿using SQLite;

namespace TravelMate.Models
{
    [Table("localTrackingData")]
    public class LocalTrackingData: BaseEntity
    {
        public Guid TravelId { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public int HeartRate { get; set; }
        public DateTime Timestamp { get; set; }
    }
}
