﻿namespace TravelMate.Enums
{
    public enum TravelDifficulty
    {
        Easy = 0,
        Moderate = 1,
        Hard = 2,
        Extreme = 3
    }
}
