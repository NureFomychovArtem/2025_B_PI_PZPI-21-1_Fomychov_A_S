﻿namespace TravelMate.Enums
{
    public enum TravelGroupStatus
    {
        Planned,
        Active,
        Completed,
        Canceled
    }
}
