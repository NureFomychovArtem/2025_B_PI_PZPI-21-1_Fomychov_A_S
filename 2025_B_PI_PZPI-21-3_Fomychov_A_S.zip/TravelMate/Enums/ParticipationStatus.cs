﻿namespace TravelMate.Enums
{
    public enum ParticipationStatus
    {
        Pending,
        Accepted,
        Rejected
    }
}
