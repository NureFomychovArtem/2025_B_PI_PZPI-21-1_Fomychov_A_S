﻿namespace TravelMate
{
    public partial class AppShell : Shell
    {
        private ShellSection _previousSection;

        public AppShell()
        {
            InitializeComponent();

            Routing.RegisterRoute(nameof(AddTravelPage), typeof(AddTravelPage));
            Routing.RegisterRoute(nameof(ChatPage), typeof(ChatPage));
            Routing.RegisterRoute(nameof(EditTravelPage), typeof(EditTravelPage));
            Routing.RegisterRoute(nameof(LoadingPage), typeof(LoadingPage));
            Routing.RegisterRoute(nameof(LoginPage), typeof(LoginPage));
            Routing.RegisterRoute(nameof(MainPage), typeof(MainPage));
            Routing.RegisterRoute(nameof(MyTravelPage), typeof(MyTravelPage));
            Routing.RegisterRoute(nameof(MessagePage), typeof(MessagePage));
            Routing.RegisterRoute(nameof(ParticipationPage), typeof(ParticipationPage));
            Routing.RegisterRoute(nameof(ProfilePage), typeof(ProfilePage));
            Routing.RegisterRoute(nameof(RegistrationPage), typeof(RegistrationPage));
            Routing.RegisterRoute(nameof(StatisticPage), typeof(StatisticPage));
            Routing.RegisterRoute(nameof(TravelDetailsPage), typeof(TravelDetailsPage));
            Routing.RegisterRoute(nameof(UpdateProfilePage), typeof(UpdateProfilePage));

            Navigated += OnShellNavigated;
        }

        private async void OnShellNavigated(object sender, ShellNavigatedEventArgs e)
        {
            var currentSection = Shell.Current.CurrentItem?.CurrentItem;

            if (_previousSection != null && currentSection != _previousSection)
            {
                await currentSection.Navigation.PopToRootAsync(false);
            }
            _previousSection = currentSection;
        }
    }
}
