﻿using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelMate.Models.DTO;
using TravelMate.Services;

namespace TravelMate.ViewModels
{
    public partial class MessageViewModel: BaseViewModel
    {
        public ObservableCollection<TravelChatDTO> Chats { get; private set; } = new();
        public MessageViewModel(MessageService messagelService)
        {
            TitlePage = "Повідомлення";
        }

        public override async Task OnAppearing()
        {
            await GetChatListAsync();
        }

        [RelayCommand]
        public async Task GetChatListAsync()
        {
            if (IsBusy) return;
            try
            {
                IsBusy = true;
                if (Chats.Any())
                    Chats.Clear();

                var chats = await App.MessageService.GetChats();

                foreach (var chat in chats)
                {
                    Chats.Add(chat);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Unable to get chats: {ex.Message}");
                await Shell.Current.DisplayAlert("Помилка", "Не вдалось завантажити чати.", "OK");
            }
            finally
            {
                IsBusy = false;
            }
        }

        [RelayCommand]
        async Task GetChat(Guid id)
        {
            if (string.IsNullOrWhiteSpace(id.ToString())) return;
            try
            {
                await Shell.Current.GoToAsync($"{nameof(ChatPage)}?Id={id.ToString()}", true);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Unable to load travel details: {ex.Message}");
                await Shell.Current.DisplayAlert("Error", "Failed to redirect to chat.", "OK");
            }
        }
    }
}
