﻿using CommunityToolkit.Mvvm.ComponentModel;
using System.Diagnostics;
using System.Web;
using TravelMate.Models.DTO;

namespace TravelMate.ViewModels
{
    public partial class StatisticsViewModel: BaseViewModel, IQueryAttributable
    {
        [ObservableProperty]
        TrackingStatistics statistics;

        public event EventHandler TravelLoaded;

        public void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            if (query.TryGetValue("Id", out var idValue))
            {
                var idStr = HttpUtility.UrlDecode(idValue?.ToString())?.Trim('"');

                if (Guid.TryParse(idStr, out var parsedGuid))
                {

                    MainThread.BeginInvokeOnMainThread(async () =>
                    {
                        Statistics = await App.ParticipationService.GetStatistics(parsedGuid);
                        TravelLoaded?.Invoke(this, EventArgs.Empty);
                    });
                }
                else
                {
                    Debug.WriteLine($"[ERROR] Failed to parse Guid from: {idStr}");
                }
            }
        }
    }
}
