﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;
using TravelMate.Enums;
using TravelMate.Models.DTO;
using TravelMate.Services;

namespace TravelMate.ViewModels
{
    public partial class AddTravelViewModel : BaseViewModel
    {
        [ObservableProperty]
        private CreateTravelDTO travelDto = new CreateTravelDTO();
        public ObservableCollection<CreateTravelLocationPointDTO> RoutePoints { get; set; } = new();

        [ObservableProperty]
        private DateTime startDate = DateTime.Today;
        [ObservableProperty]
        private TimeSpan startTime = DateTime.Now.TimeOfDay;
        [ObservableProperty]
        private DateTime endDate = DateTime.Today;
        [ObservableProperty]
        private TimeSpan endTime = DateTime.Now.AddHours(1).TimeOfDay;

        public DateTime FullStartTime => StartDate.Date + StartTime;
        public DateTime FullEndTime => EndDate.Date + EndTime;

        public List<TravelDifficulty> TravelDifficulties { get; } =
                Enum.GetValues(typeof(TravelDifficulty)).Cast<TravelDifficulty>().ToList();
        
        [ObservableProperty]
        private TravelDifficulty selectedDifficulty = TravelDifficulty.Moderate;

        public AddTravelViewModel(TravelService travelService)
        {
            TitlePage = "Створити подорож";
        }

        [RelayCommand]
        public async Task AddTravelAsync()
        {
            if (IsBusy) return;
            IsBusy = true;
            try
            {
                TravelDto.RoutePoints = RoutePoints.ToList();
                TravelDto.StartTime = FullStartTime;
                TravelDto.EndTime = FullEndTime;
                TravelDto.Difficulty = SelectedDifficulty;

                if (string.IsNullOrWhiteSpace(TravelDto.Title) ||
                    string.IsNullOrWhiteSpace(TravelDto.Description) ||
                    TravelDto.MaxParticipants <= 1 ||
                    TravelDto.StartTime < DateTime.UtcNow ||
                    TravelDto.EndTime < TravelDto.StartTime ||
                    TravelDto.RoutePoints.Count() < 2)
                {
                    await DisplayCreateError("Всі поля повинні бути заповнені");
                    return;
                }

                if (await App.TravelService.AddTravelAsync(TravelDto))
                {
                    await Shell.Current.GoToAsync("//MainPage");
                    return;
                }
                await DisplayCreateError("Помилка при створені подорожі.");
            }
            catch (Exception ex)
            {
                await DisplayCreateError(ex.Message);
                return;
            }
            finally
            {
                IsBusy = false;
            }
        }

        async Task DisplayCreateError(string errorMessage)
        {
            await Shell.Current.DisplayAlert("Некоректні дані", errorMessage, "OK");
        }
    }
}
