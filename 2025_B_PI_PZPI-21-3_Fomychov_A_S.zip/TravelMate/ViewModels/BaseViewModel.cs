﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace TravelMate.ViewModels
{
    public partial class BaseViewModel : ObservableObject
    {
        [ObservableProperty]
        string titlePage;

        [NotifyPropertyChangedFor(nameof(isNotBusy))]
        [ObservableProperty]
        private bool isBusy;
        public bool isNotBusy => !isBusy;

        public virtual Task OnAppearing() => Task.CompletedTask;

        [RelayCommand]
        public async Task Back()
        {
            await Shell.Current.GoToAsync("..");
        }
    }
}
