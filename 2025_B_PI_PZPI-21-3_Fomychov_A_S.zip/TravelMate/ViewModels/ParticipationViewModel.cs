﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Web;
using TravelMate.Enums;
using TravelMate.Models.DTO;
using TravelMate.Services;

namespace TravelMate.ViewModels
{
    public partial class ParticipationViewModel : BaseViewModel, IQueryAttributable
    {
        public ObservableCollection<GroupParticipationDTO> AcceptedParticipants { get; private set; } = new();
        public ObservableCollection<GroupParticipationDTO> PendingParticipants { get; private set; } = new();

        private string travelId = string.Empty;
        public ParticipationViewModel(ParticipationService participationService)
        {
            TitlePage = "Travel List";
        }
        public void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            if (query.TryGetValue("Id", out var idValue))
            {
                travelId = HttpUtility.UrlDecode(idValue?.ToString())?.Trim('"');

                MainThread.BeginInvokeOnMainThread(async () =>
                {
                    var participations = await App.ParticipationService.GetParticipationsByTravelId(travelId);

                    var usernameOrEmail = await SecureStorage.Default.GetAsync("emailOrUsername");

                    var currentUser = participations.FirstOrDefault(p =>
                        p.Username == usernameOrEmail || p.Email == usernameOrEmail);

                    AcceptedParticipants.Clear();
                    PendingParticipants.Clear();

                    foreach (var participant in participations)
                    {
                        if (participant.Status == ParticipationStatus.Accepted)
                            AcceptedParticipants.Add(participant);
                        else if (participant.Status == ParticipationStatus.Pending)
                            PendingParticipants.Add(participant);
                    }
                });
            }
        }

        [RelayCommand]
        public async Task ApproveAsync(GroupParticipationDTO participation)
        {
            if (IsBusy) return;
            try
            {
                IsBusy = true;
                if (participation is null) throw new Exception("Заявка не знайдена");
                var success = await App.ParticipationService.ChangeParticipationStatusAsync(participation.Id, "1");
                if (success)
                {
                    AcceptedParticipants.Add(participation);
                    PendingParticipants.Remove(participation);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Unable to accept participation: {ex.Message}");
                await Shell.Current.DisplayAlert("Error", "Помилка схвалення заявки.", "OK");
            }
            finally
            {
                IsBusy = false;
            }
        }

        [RelayCommand]
        public async Task RejectAsync(GroupParticipationDTO participation)
        {
            if (IsBusy) return;
            try
            {
                IsBusy = true;
                if (participation is null) throw new Exception("Заявка не знайдена");
                var success = await App.ParticipationService.ChangeParticipationStatusAsync(participation.Id, "2");
                if (success)
                {
                    AcceptedParticipants.Remove(participation);
                    PendingParticipants.Remove(participation);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Unable to reject participation: {ex.Message}");
                await Shell.Current.DisplayAlert("Error", "Помилка відхилення заявки.", "OK");
            }
            finally
            {
                IsBusy = false;
            }
        }
    
        
    }
}
