﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using NetTopologySuite.Operation.Valid;
using System.Text.RegularExpressions;
using TravelMate.Models.DTO;
using TravelMate.Services;

namespace TravelMate.ViewModels
{
    public partial class LoginViewModel: BaseViewModel
    {
        [ObservableProperty]
        private LoginDTO loginDto = new LoginDTO("", "");

        [ObservableProperty]
        private bool isRememberMeChecked = true;

        public LoginViewModel(AuthService authService)
        {
            TitlePage = "Login";
        }


        [RelayCommand]
        public async Task LoginAsync()
        {
            if (IsBusy) return;
            IsBusy = true;
            try
            {
                if (!IsValidData())
                {
                    await DisplayLoginError("Всі поля повинні бути заповнені коректно");
                    return;
                }
                var token = await App.AuthService.LoginAsync(LoginDto);

                await SecureStorage.SetAsync("auth_token", token);
                await SecureStorage.SetAsync("emailOrUsername", LoginDto.EmailOrUsername);
                await SecureStorage.SetAsync("password", LoginDto.Password);
            }
            catch (Exception ex)
            {
                await DisplayLoginError(ex.Message);
                return;
            }
            finally
            {
                IsBusy = false;
            }

            await Shell.Current.GoToAsync("//ProfilePage");
        }

        [RelayCommand]
        public async Task RegistrationAsync()
        {
            await Shell.Current.GoToAsync($"{nameof(RegistrationPage)}");
        }

        async Task DisplayLoginError(string errorMessage)
        {
            await Shell.Current.DisplayAlert("Некоректні дані", errorMessage, "OK");
        }

        private bool IsValidData()
        {
            if (string.IsNullOrWhiteSpace(loginDto.EmailOrUsername) || string.IsNullOrWhiteSpace(loginDto.Password))
                return false;

            if (loginDto.Password.Length < 6)
            {
                return false;
            }

            if (loginDto.EmailOrUsername.Contains("@"))
            {
                try
                {
                    var addr = new System.Net.Mail.MailAddress(loginDto.EmailOrUsername);
                    return addr.Address == loginDto.EmailOrUsername;
                }
                catch
                {
                    return false;
                }
            }
            else
            {
                return loginDto.EmailOrUsername.Length >= 3 && Regex.IsMatch(loginDto.EmailOrUsername, @"^[a-zA-Z0-9_.-]+$");
            }
        }
    }
}
  