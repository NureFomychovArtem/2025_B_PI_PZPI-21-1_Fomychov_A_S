﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Diagnostics;
using System.Web;
using TravelMate.Enums;
using TravelMate.Models.DTO;

namespace TravelMate.ViewModels
{
    public partial class TravelDetailsViewModel : BaseViewModel, IQueryAttributable
    {
        [ObservableProperty]
        TravelDTO travel;

        [ObservableProperty]
        bool showJoinButton;
        [ObservableProperty]
        bool showStartButton;
        [ObservableProperty]
        bool showEndButton;
        [ObservableProperty]
        bool showEditButton;
        [ObservableProperty]
        bool showStatisticButton;
        [ObservableProperty]
        bool isAdmin;
        [ObservableProperty]
        bool isParticipant;

        public int CurrentParticipantsCount =>
            Travel?.GroupParticipationDtos?.Count(p => p.Status == ParticipationStatus.Accepted) ?? 0;

        public string ParticipantsText => $"Учасників: {CurrentParticipantsCount}/{Travel?.MaxParticipants ?? 0}";
        public event EventHandler TravelLoaded;

        public void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            if (query.TryGetValue("Id", out var idValue))
            {
                var idStr = HttpUtility.UrlDecode(idValue?.ToString())?.Trim('"');

                if (Guid.TryParse(idStr, out var parsedGuid))
                {

                    MainThread.BeginInvokeOnMainThread(async () =>
                    {
                        Travel = await App.TravelService.GetTrevel(parsedGuid);
                        OnPropertyChanged(nameof(CurrentParticipantsCount));
                        OnPropertyChanged(nameof(ParticipantsText));
                        TravelLoaded?.Invoke(this, EventArgs.Empty);

                        var emailOrUsername = await SecureStorage.GetAsync("emailOrUsername");

                        var isPlannedTravel = Travel.Status == TravelGroupStatus.Planned;
                        var isActiveTravel = Travel.Status == TravelGroupStatus.Active;
                        
                        ShowStatisticButton = Travel.Status == TravelGroupStatus.Completed;

                        ShowJoinButton = !Travel.GroupParticipationDtos.Any(p => p.Username == emailOrUsername || p.Email == emailOrUsername);
                        IsAdmin = Travel.GroupParticipationDtos.Any(p => (p.Username == emailOrUsername || p.Email == emailOrUsername) && p.IsAdmin);
                        IsParticipant = Travel.GroupParticipationDtos.Any(p =>
                                            (p.Username == emailOrUsername || p.Email == emailOrUsername)
                                            && p.Status == ParticipationStatus.Accepted);

                        ShowEditButton = IsAdmin && isPlannedTravel;
                        ShowStartButton = IsAdmin && isPlannedTravel;
                        ShowEndButton = IsParticipant && isActiveTravel;
                    });
                }
                else
                {
                    Debug.WriteLine($"[ERROR] Failed to parse Guid from: {idStr}");
                }
            }
        }

        [RelayCommand]
        private async Task JoinTravelAsync()
        {
            if (IsBusy) return;

            try
            {
                IsBusy = true;
                if (Travel is null) throw new Exception("Travel was not found");

                var success = await App.ParticipationService.CreateParticipationAsync(Travel.Id);

                if (success)
                {
                    Travel = await App.TravelService.GetTrevel(Travel.Id);
                    ShowJoinButton = false;
                }
            }
            catch (Exception ex)
            {
                await Shell.Current.DisplayAlert("Помилка", "Не вдалося приєднатися до подорожі", "OK");
            }
            finally
            {
                IsBusy = false;
            }
        }

        [RelayCommand]
        private async Task StartTravelAsync()
        {
            if (IsBusy) return;

            try
            {
                IsBusy = true;
                if (Travel is null) throw new Exception("Travel was not found");

                var dto = new StatusTravelDTO
                {
                    TravelGroupId = Travel.Id,
                    Status = TravelGroupStatus.Active
                };

                var emailOrUsername = await SecureStorage.GetAsync("emailOrUsername");
                var participation = Travel.GroupParticipationDtos.FirstOrDefault(p => p.Username == emailOrUsername || p.Email == emailOrUsername);

                var success = await App.ParticipationService.ConfirmParticipation(participation.Id);
                if (!success)
                {
                    throw new Exception("Не вдалося підтвердити участь у подорожі");
                }

                if (isAdmin)
                {
                    success = await App.TravelService.ChangeStatusTravel(dto);
                }

                if (success)
                {
                    Travel = await App.TravelService.GetTrevel(Travel.Id);
                    ShowStartButton = false;
                    ShowEditButton = false;
                    ShowEndButton = true;
                }
            }
            catch (Exception ex)
            {
                await Shell.Current.DisplayAlert("Помилка", "Не вдалося приєднатися до подорожі", "OK");
            }
            finally
            {
                IsBusy = false;
            }
        }

        [RelayCommand]
        private async Task EndTravelAsync()
        {
            if (IsBusy) return;

            try
            {
                IsBusy = true;
                if (Travel is null) throw new Exception("Travel was not found");

                var dto = new StatusTravelDTO
                {
                    TravelGroupId = Travel.Id,
                    Status = TravelGroupStatus.Completed
                };

                var emailOrUsername = await SecureStorage.GetAsync("emailOrUsername");
                var participation = Travel.GroupParticipationDtos.FirstOrDefault(p => p.Username == emailOrUsername || p.Email == emailOrUsername);

                try
                {
                    await App.TrackingService.StopTracking();
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"[ERROR] Failed to stop tracking: {ex.Message}");
                }

                if (isAdmin)
                {
                    var success = await App.TravelService.ChangeStatusTravel(dto);
                }
                Travel = await App.TravelService.GetTrevel(Travel.Id);
                ShowEndButton = false;
                ShowStatisticButton = true;
            }
            catch (Exception ex)
            {
                await Shell.Current.DisplayAlert("Помилка", "Не вдалося приєднатися до подорожі", "OK");
            }
            finally
            {
                IsBusy = false;
            }
        }

        [RelayCommand]
        async Task StatisticTravel()
        {
            if (string.IsNullOrWhiteSpace(Travel.Id.ToString())) return;
            try
            {
                var emailOrUsername = await SecureStorage.GetAsync("emailOrUsername");

                var participation = Travel.GroupParticipationDtos.FirstOrDefault(p => p.Username == emailOrUsername || p.Email == emailOrUsername);

                await Shell.Current.GoToAsync($"{nameof(StatisticPage)}?Id={participation.Id.ToString()}");
            }
            catch (Exception ex)
            {
                await Shell.Current.DisplayAlert("Помилка", "Помилка переходу на сторінку статистики", "OK");
            }
        }

        [RelayCommand]
        private async Task EditTravelAsync()
        {

            if (string.IsNullOrWhiteSpace(Travel.Id.ToString())) return;
            try
            {
                await Shell.Current.GoToAsync($"{nameof(EditTravelPage)}?Id={Travel.Id.ToString()}", true);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Unable to load travel details: {ex.Message}");
                await Shell.Current.DisplayAlert("Error", "Failed to load travel details.", "OK");
            }
        }

        [RelayCommand]
        private async Task GetTravelParticipationAsync()
        {
            if (string.IsNullOrWhiteSpace(Travel.Id.ToString())) return;
            try
            {
                await Shell.Current.GoToAsync($"{nameof(ParticipationPage)}?Id={Travel.Id.ToString()}", true);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Unable to load travel details: {ex.Message}");
                await Shell.Current.DisplayAlert("Error", "Failed to load travel details.", "OK");
            }
        }
    }
}
