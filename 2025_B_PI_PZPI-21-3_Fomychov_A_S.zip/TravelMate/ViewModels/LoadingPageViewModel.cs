﻿using System.IdentityModel.Tokens.Jwt;
using TravelMate.Models.DTO;
using TravelMate.Services;

namespace TravelMate.ViewModels
{
    public partial class LoadingPageViewModel : BaseViewModel
    {
        private readonly AuthService _authService;
        public LoadingPageViewModel(AuthService authService)
        {
            CheckUserLoginDetails();
        }

        private async void CheckUserLoginDetails()
        {
            var token = await SecureStorage.GetAsync("auth_token");
            if (!string.IsNullOrEmpty(token))
            {
                var jwtToken = new JwtSecurityTokenHandler().ReadToken(token) as JwtSecurityToken;

                if (jwtToken?.ValidTo > DateTime.UtcNow)
                {
                    await GoToMainPage();
                    return;
                }
                else
                {
                    SecureStorage.Remove("auth_token");
                }
            }

            var username = await SecureStorage.GetAsync("emailOrUsername");
            var password = await SecureStorage.GetAsync("password");

            if (!string.IsNullOrWhiteSpace(username) && !string.IsNullOrWhiteSpace(password))
            {
                var loginDto = new LoginDTO(username, password);

                try
                {
                    var newToken = await App.AuthService.LoginAsync(loginDto);

                    if (string.IsNullOrEmpty(newToken))
                    {
                        await GoToLoginPage();
                        return;
                    }
                    await SecureStorage.SetAsync("auth_token", newToken);
                }
                catch (Exception ex)
                {
                    await GoToLoginPage();
                    return;
                }
                await GoToMainPage();
            }
            else
            {
                await GoToLoginPage();
            }
        }

        private async Task GoToLoginPage()
        {
            await Shell.Current.GoToAsync($"{nameof(LoginPage)}");
        }

        private async Task GoToMainPage()
        {
            await Shell.Current.GoToAsync("//MainPage");
        }
    }

}
