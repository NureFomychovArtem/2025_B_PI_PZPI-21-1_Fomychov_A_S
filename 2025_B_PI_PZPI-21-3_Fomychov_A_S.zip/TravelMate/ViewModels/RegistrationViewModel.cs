﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Text.RegularExpressions;
using TravelMate.Models.DTO;
using TravelMate.Services;

namespace TravelMate.ViewModels
{
    public partial class RegistrationViewModel: BaseViewModel
    {
        [ObservableProperty]
        private RegistrationDTO registrationDto = new RegistrationDTO(string.Empty, string.Empty, string.Empty, string.Empty, string.Empty);
        [ObservableProperty]
        private string confirmPassword;

        [ObservableProperty]
        private bool isRememberMeChecked = true;

        public RegistrationViewModel(AuthService authService)
        {
            TitlePage = "Login";
        }

        [RelayCommand]
        public async Task RegistrationAsync()
        {
            if (IsBusy) return;
            IsBusy = true;
            try
            {
                if (!IsValidData())
                {
                    await DisplayRegistrationError("Всі поля повинні бути заповнені коректно");
                    return;
                }

                if (RegistrationDto.Password != confirmPassword)
                {
                    await DisplayRegistrationError("Паролі не співпадають");
                    return;
                }

                await App.AuthService.RegistrationAsync(RegistrationDto);

                await Shell.Current.DisplayAlert(
                    "Підтвердіть електронну пошту",
                    "Реєстрація успішна! Будь ласка, перевірте свою електронну пошту та підтвердьте свій обліковий запис перед входом.",
                    "OK"
                );

                await Shell.Current.GoToAsync($"{nameof(LoginPage)}");
            }
            catch (Exception ex)
            {
                await DisplayRegistrationError(ex.Message);
                return;
            }
            finally
            {
                IsBusy = false;
            }
        }

        [RelayCommand]
        public async Task LoginAsync()
        {
            await Shell.Current.GoToAsync($"{nameof(LoginPage)}");
        }

        async Task DisplayRegistrationError(string errorMessage)
        {
            await Shell.Current.DisplayAlert("Некоректні дані", errorMessage, "OK");
        }

        private bool IsValidData()
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(registrationDto.Email);
                
                if (addr.Address == registrationDto.Email &&

                !string.IsNullOrWhiteSpace(registrationDto.FirstName) &&
                registrationDto.FirstName.Length >= 2 &&
                Regex.IsMatch(registrationDto.FirstName, @"^[a-zA-Zа-яА-ЯїЇєЄґҐіІ'\s\-]+$") &&

                !string.IsNullOrWhiteSpace(registrationDto.LastName) &&
                registrationDto.LastName.Length >= 2 &&
                Regex.IsMatch(registrationDto.LastName, @"^[a-zA-Zа-яА-ЯїЇєЄґҐіІ'\s\-]+$") &&

                !string.IsNullOrWhiteSpace(registrationDto.Username) &&
                registrationDto.Username.Length >= 3 &&

                !string.IsNullOrWhiteSpace(registrationDto.Password) &&
                registrationDto.Password.Length >= 6 &&
                Regex.IsMatch(registrationDto.Password, @"[A-Z]") &&        
                Regex.IsMatch(registrationDto.Password, @"[a-z]") &&        
                Regex.IsMatch(registrationDto.Password, @"[0-9]")
                )
                    return true;

                return false;
            }
            catch
            {
                return false;
            }
        }
    }
}
