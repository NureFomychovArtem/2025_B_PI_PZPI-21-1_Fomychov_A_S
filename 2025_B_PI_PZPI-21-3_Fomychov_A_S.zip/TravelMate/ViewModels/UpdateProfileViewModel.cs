﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Diagnostics;
using System.Text.Json;
using TravelMate.Models.DTO;

namespace TravelMate.ViewModels
{
    public partial class UpdateProfileViewModel : BaseViewModel, IQueryAttributable
    {
        [ObservableProperty]
        UpdateUserDTO user;
        [ObservableProperty]
        private Guid id;

        public void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            if (query.TryGetValue("Id", out var idValue))
            {
                var idStr = Uri.UnescapeDataString(idValue?.ToString() ?? "").Trim('"');

                if (Guid.TryParse(idStr, out var parsedId))
                {
                    Id = parsedId;

                    MainThread.BeginInvokeOnMainThread(async () =>
                    {
                        var profile = await App.UserService.GetProfileAsync();
                        var password = await SecureStorage.GetAsync("password");
                        User = new UpdateUserDTO
                        {
                            FirstName = profile.FirstName,
                            LastName = profile.FirstName,
                            DateOfBirth = profile.DateOfBirth,
                            PhoneNumber = profile.PhoneNumber,
                            City = profile.City,
                            Country = profile.Country,
                            Bio = profile.Bio,
                            Password = password
                        };
                    });
                }
            }
        }

        [RelayCommand]
        public async Task Save()
        {
            try
            {
                var success = await App.UserService.UpdateProfileAsync(Id, User);
                if (success)
                    await Shell.Current.GoToAsync("..");
                else
                    await Shell.Current.DisplayAlert("Помилка", "Не вдалося оновити", "OK");
            }
            catch (Exception ex)
            {
                await Shell.Current.DisplayAlert("Помилка", ex.Message, "OK");
            }
        }
    }
}


