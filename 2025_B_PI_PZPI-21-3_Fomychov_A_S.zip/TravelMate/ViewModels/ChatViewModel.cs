﻿using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Web;
using TravelMate.Models.DTO;

namespace TravelMate.ViewModels
{
    public partial class ChatViewModel : BaseViewModel, IQueryAttributable
    {
        private Guid CurrentTravelId;
        public string CurrentUsername { get; set; }

        public ObservableCollection<MessageDTO> Messages { get; private set; } = new();

        public void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            if (query.TryGetValue("Id", out var idValue))
            {
                var idStr = HttpUtility.UrlDecode(idValue?.ToString())?.Trim('"');

                if (Guid.TryParse(idStr, out var parsedGuid))
                {
                    CurrentTravelId = parsedGuid;
                    MainThread.BeginInvokeOnMainThread(async () =>
                    {
                        await LoadMessagesAsync();
                        CurrentUsername = await SecureStorage.GetAsync("username");
                    });
                }
                else
                {
                    Debug.WriteLine($"[ERROR] Failed to parse Guid from: {idStr}");
                }
            }
        }

        private async Task LoadMessagesAsync()
        {
            Messages.Clear();
            var messages = await App.MessageService.GetMessages(CurrentTravelId);

            foreach (var message in messages)
            {
                Messages.Add(message);
            }
        }

        public async Task SendMessage(string text)
        {
            var message = new CreateMessageDTO
            {
                Text = text,
                TravelGroupId = CurrentTravelId,
            };
            var isSuccess = await App.MessageService.SendMessage(message);
            
            if(isSuccess)
            {
                await LoadMessagesAsync();
            }
        }
    }
}
