﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;
using System.Diagnostics;
using TravelMate.Models.DTO;
using TravelMate.Services;

namespace TravelMate.ViewModels
{
    public partial class MyTravelViewModel : BaseViewModel
    {
        public ObservableCollection<TravelDTO> Travels { get; private set; } = new();
        public MyTravelViewModel(TravelService travelService)
        {
            TitlePage = "Мої подорожі";
        }

        [ObservableProperty]
        bool isRefreshing;

        public override async Task OnAppearing()
        {
            await GetTravelListAsync();
        }

        [RelayCommand]
        public async Task GetTravelListAsync()
        {
            if (IsBusy) return;
            try
            {
                IsBusy = true;
                if (Travels.Any())
                    Travels.Clear();

                var travels = await App.TravelService.GetTrevels();

                var emailOrUsername = await SecureStorage.GetAsync("emailOrUsername");
                var participation = new GroupParticipationDTO();
                
                foreach (var travel in travels)
                {
                    participation = travel.GroupParticipationDtos.FirstOrDefault(p => p.Username == emailOrUsername || p.Email == emailOrUsername);
                    if(participation != null)
                        Travels.Add(travel);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Unable to get travels: {ex.Message}");
                await Shell.Current.DisplayAlert("Error", "Failed to retrive list of travels.", "OK");
            }
            finally
            {
                IsBusy = false;
                IsRefreshing = false;
            }
        }

        [RelayCommand]
        async Task GetTravelDetails(Guid id)
        {
            if (string.IsNullOrWhiteSpace(id.ToString())) return;
            try
            {
                await Shell.Current.GoToAsync($"{nameof(TravelDetailsPage)}?Id={id.ToString()}", true);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Unable to load travel details: {ex.Message}");
                await Shell.Current.DisplayAlert("Error", "Failed to load travel details.", "OK");
            }
        }
    }
}
