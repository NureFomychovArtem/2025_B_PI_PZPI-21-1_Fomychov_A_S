﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Text.Json;
using TravelMate.Models;
using TravelMate.Models.DTO;
using TravelMate.Services;

namespace TravelMate.ViewModels
{
    public partial class ProfileViewModel : BaseViewModel
    {
        [ObservableProperty]
        private User user;

        private readonly UserService _userService;
        public ProfileViewModel(UserService userService)
        {
            TitlePage = "Профіль";
            _userService = userService;
        }

        public override async Task OnAppearing()
        {
            await LoadUserProfileAsync();
        }

        [RelayCommand]
        private async Task LoadUserProfileAsync()
        {
            if (IsBusy) return;
            try
            {
                IsBusy = true;
                User = await App.UserService.GetProfileAsync();

                await SecureStorage.SetAsync("email", User.Email);
                await SecureStorage.SetAsync("username", User.Username);
                await SecureStorage.SetAsync("avatarUrl", User.AvatarUrl ?? string.Empty);
            }
            catch (Exception ex)
            {
                await Shell.Current.DisplayAlert("Помилка", $"Не вдалося отримати інформацію про користувача: {ex.Message}", "OK");
            }
            finally
            {
                IsBusy = false;
            }
        }

        [RelayCommand]
        async Task EditProfile()
        {
            if (string.IsNullOrWhiteSpace(User.Id.ToString())) return;
            try
            {
                var userId = User.Id.ToString();

                await Shell.Current.GoToAsync($"{nameof(UpdateProfilePage)}?Id={userId}");
            }
            catch (Exception ex)
            {
                await Shell.Current.DisplayAlert("Помилка", "Помилка переходу на сторінку редагування", "OK");
            }
        }

        [RelayCommand]
        public async Task EditAvatar()
        {
            try
            {
                var result = await MainThread.InvokeOnMainThreadAsync(() =>
                    FilePicker.Default.PickAsync(new PickOptions
                    {
                        PickerTitle = "Виберіть аватар",
                        FileTypes = FilePickerFileType.Images
                    })
                );

                if (result is null)
                    return;

                using var stream = await result.OpenReadAsync();

                using var memoryStream = new MemoryStream();
                await stream.CopyToAsync(memoryStream);
                var imageBytes = memoryStream.ToArray();

                memoryStream.Position = 0;
                var uploadSuccess = await App.UserService.UploadAvatarAsync(new MemoryStream(imageBytes), result.FileName);

                if (uploadSuccess)
                {
                    await LoadUserProfileAsync();
                }
            }
            catch (Exception ex)
            {
                await Shell.Current.DisplayAlert("Помилка", $"Щось пішло не так: {ex.Message}", "ОК");
            }
        }

        [RelayCommand]
        async Task LogoutAsync()
        {
            try
            {
                SecureStorage.Remove("auth_token");
                SecureStorage.Remove("emailOrUsername");
                SecureStorage.Remove("username");
                SecureStorage.Remove("email");
                SecureStorage.Remove("password");

                await _userService.LogoutAsync();
                await Shell.Current.GoToAsync($"{nameof(LoginPage)}");

                Shell.Current.FlyoutBehavior = FlyoutBehavior.Disabled;
            }
            catch (Exception ex)
            {
                await Shell.Current.DisplayAlert("Помилка", $"Не вдалося вийти з системи: {ex.Message}", "OK");
            }
        }
    }
}
