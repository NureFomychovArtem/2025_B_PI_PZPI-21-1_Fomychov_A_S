﻿using CommunityToolkit.Maui.Views;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Web;
using TravelMate.Models.DTO;
using TravelMate.Services;

namespace TravelMate.ViewModels
{
    public partial class EditTravelViewModel : BaseViewModel, IQueryAttributable
    {
        [ObservableProperty]
        private UpdateTravelDTO travelDto = new UpdateTravelDTO();
        public ObservableCollection<TravelLocationPointOM> RoutePoints { get; set; } = new();

        [ObservableProperty]
        private DateTime startDate;
        [ObservableProperty]
        private TimeSpan startTime;
        [ObservableProperty]
        private DateTime endDate;
        [ObservableProperty]
        private TimeSpan endTime;

        public DateTime FullStartTime => StartDate.Date + StartTime;
        public DateTime FullEndTime => EndDate.Date + EndTime;

        public event EventHandler TravelLoaded;

        public EditTravelViewModel(TravelService travelService)
        {
            TitlePage = travelDto.Title;
        }

        public void ApplyQueryAttributes(IDictionary<string, object> query)
        {
            if (query.TryGetValue("Id", out var idValue))
            {
                var idStr = HttpUtility.UrlDecode(idValue?.ToString())?.Trim('"');

                if (Guid.TryParse(idStr, out var parsedGuid))
                {

                    MainThread.BeginInvokeOnMainThread(async () =>
                    {
                        var travel = await App.TravelService.GetTrevel(parsedGuid);

                        TravelDto = new UpdateTravelDTO
                        {
                            Id = travel.Id,
                            Title = travel.Title,
                            Description = travel.Description,
                            MaxParticipants = travel.MaxParticipants,
                            StartTime = travel.StartTime,
                            EndTime = travel.EndTime,
                            Status = travel.Status,
                            Difficulty = travel.Difficulty
                        };

                        StartDate = travel.StartTime?.Date ?? DateTime.Today;
                        StartTime = travel.StartTime?.TimeOfDay ?? DateTime.Today.TimeOfDay;
                        EndDate = travel.EndTime?.Date ?? DateTime.Today;
                        EndTime = travel.EndTime?.TimeOfDay ?? DateTime.Today.TimeOfDay;

                        RoutePoints.Clear();
                        foreach (var point in travel.RoutePoints)
                        {
                            RoutePoints.Add(new TravelLocationPointOM
                            {
                                Id = point.Id,
                                Latitude = point.Latitude,
                                Longitude = point.Longitude,
                                Name = point.Name,
                                Description = point.Description,
                                Order = point.Order
                            });
                        }

                        TravelLoaded?.Invoke(this, EventArgs.Empty);
                    });
                }
                else
                {
                    Debug.WriteLine($"[ERROR] Failed to parse Guid from: {idStr}");
                }
            }
        }

        [RelayCommand]
        public async Task EditTravelAsync()
        {
            if (IsBusy) return;
            IsBusy = true;
            try
            {

                foreach (var point in RoutePoints)
                {
                    TravelDto.RoutePoints.Add(new TravelLocationPointDTO
                    {
                        Id = point.Id,
                        Latitude = point.Latitude,
                        Longitude = point.Longitude,
                        Name = point.Name,
                        Description = point.Description,
                        Order = point.Order
                    });
                }

                TravelDto.StartTime = FullStartTime;
                TravelDto.EndTime = FullEndTime;
                if (string.IsNullOrWhiteSpace(TravelDto.Title) ||
                    string.IsNullOrWhiteSpace(TravelDto.Description) ||
                    TravelDto.MaxParticipants <= 1 ||
                    TravelDto.StartTime < DateTime.UtcNow ||
                    TravelDto.EndTime < TravelDto.StartTime ||
                    TravelDto.RoutePoints.Count() < 2)
                {
                    await DisplayEditError("Всі поля повинні бути заповнені");
                    return;
                }
                var travel = await App.TravelService.UpdateTravelAsync(TravelDto);
                if (travel != null)
                {
                    await Shell.Current.GoToAsync($"{nameof(TravelDetailsPage)}?Id={TravelDto.Id.ToString()}", true);
                    return;
                }
                await DisplayEditError("Помилка при оновленні подорожі.");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[ERROR] Failed to update travel: {ex.Message}");
                await DisplayEditError("Сталася помилка при оновленні подорожі.");
            }
            finally
            {
                IsBusy = false;
            }
        }

        [RelayCommand]  
        private async Task SelectCoordinatesAsync(TravelLocationPointOM point)
        {
            var popup = new SelectCoordinatePopup();
            var result = await Application.Current.MainPage.ShowPopupAsync(popup) as SelectCoordinatePopup;
            var position = await popup.GetCoordinateAsync();

            if (position != null)
            {
                point.Latitude = position.Value.Latitude;
                point.Longitude = position.Value.Longitude;
            }

            TravelLoaded?.Invoke(this, EventArgs.Empty);
        }

        private async Task DisplayEditError(string errorMessage)
        {
            await Shell.Current.DisplayAlert("Некоректні дані", errorMessage, "OK");
        }
    }
}