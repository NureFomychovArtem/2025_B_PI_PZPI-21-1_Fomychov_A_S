﻿using Maui.GoogleMaps.Hosting;
using CommunityToolkit.Maui;
using Microsoft.Extensions.Logging;
using TravelMate.Services;
using TravelMate.ViewModels;

namespace TravelMate
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .UseMauiCommunityToolkit()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                });


            string dbPath = Path.Combine(FileSystem.AppDataDirectory, "travelMate.db3");
            
            builder.Services.AddSingleton<App>();

            builder.Services.AddSingleton(s => ActivatorUtilities.CreateInstance<LocalDatabaseService>(s, dbPath));

            builder.Services.AddSingleton<AuthService>();
            builder.Services.AddSingleton<FitnessTrackerService>();
            builder.Services.AddSingleton<ParticipationService>();
            builder.Services.AddSingleton<MessageService>();
            builder.Services.AddSingleton<TrackingService>();
            builder.Services.AddSingleton<TravelService>();
            builder.Services.AddSingleton<UserService>();

            builder.Services.AddSingleton<AddTravelViewModel>();
            builder.Services.AddSingleton<ChatViewModel>();
            builder.Services.AddSingleton<EditTravelViewModel>();
            builder.Services.AddSingleton<LoadingPageViewModel>();
            builder.Services.AddSingleton<LoginViewModel>();
            builder.Services.AddSingleton<ParticipationViewModel>();
            builder.Services.AddSingleton<ProfileViewModel>();
            builder.Services.AddSingleton<RegistrationViewModel>();
            builder.Services.AddSingleton<MessageViewModel>();
            builder.Services.AddSingleton<MyTravelViewModel>();
            builder.Services.AddSingleton<TravelListViewModel>();
            builder.Services.AddTransient<StatisticsViewModel>();
            builder.Services.AddTransient<TravelDetailsViewModel>();
            builder.Services.AddTransient<UpdateProfileViewModel>();

            builder.Services.AddSingleton<AddTravelPage>();
            builder.Services.AddSingleton<ChatPage>();
            builder.Services.AddSingleton<EditTravelPage>();
            builder.Services.AddSingleton<LoadingPage>();
            builder.Services.AddSingleton<LoginPage>();
            builder.Services.AddSingleton<ProfilePage>();
            builder.Services.AddSingleton<ParticipationPage>();
            builder.Services.AddSingleton<RegistrationPage>();
            builder.Services.AddSingleton<MainPage>();
            builder.Services.AddSingleton<MyTravelPage>();
            builder.Services.AddSingleton<MessagePage>();
            builder.Services.AddTransient<StatisticPage>();
            builder.Services.AddTransient<TravelDetailsPage>();
            builder.Services.AddTransient<UpdateProfilePage>();

#if DEBUG
            builder.Logging.AddDebug();
#endif
#if ANDROID
            builder.UseGoogleMaps( );
#elif IOS
        builder.UseGoogleMaps("AIzaSyDYqPTxAIzaSyDFbB9UAg55Hh2IRZsTMAEtP8pyZ2MybJA");
#endif
            return builder.Build();
        }
    }
}
