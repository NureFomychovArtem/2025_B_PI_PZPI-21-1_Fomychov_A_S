﻿using TravelMate.Services;

namespace TravelMate
{
    public partial class App : Application
    {
        public static AuthService AuthService { get; private set; }
        public static ParticipationService ParticipationService { get; private set; }
        public static MessageService MessageService { get; private set; }
        public static TrackingService TrackingService { get; private set; }
        public static TravelService TravelService { get; private set; }
        public static UserService UserService { get; private set; }
        public App(AuthService authService,
            MessageService messageService,
            TrackingService trackingService,
            TravelService travelService,
            ParticipationService participationService,
            UserService userService)
        {
            InitializeComponent();

            MainPage = new AppShell();
            AuthService = authService;
            ParticipationService = participationService;
            MessageService = messageService;
            TrackingService = trackingService;
            TravelService = travelService;
            UserService = userService;
        }
    }
}
