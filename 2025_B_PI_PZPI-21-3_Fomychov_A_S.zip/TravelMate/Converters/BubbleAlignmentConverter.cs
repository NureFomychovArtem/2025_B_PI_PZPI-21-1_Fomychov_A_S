﻿using System.Globalization;

namespace TravelMate.Converters
{
    public class BubbleAlignmentConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var username = value as string;
            var currentUsername = SecureStorage.GetAsync("username").Result;

            return username == currentUsername ? LayoutOptions.End : LayoutOptions.Start;
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
    }
}

