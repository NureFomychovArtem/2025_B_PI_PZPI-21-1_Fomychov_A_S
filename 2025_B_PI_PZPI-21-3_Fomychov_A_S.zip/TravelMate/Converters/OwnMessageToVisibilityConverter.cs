﻿using System.Globalization;

namespace TravelMate.Converters
{
    public class OwnMessageToVisibilityConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values.Length < 2 || values[0] is not string messageUsername || values[1] is not string currentUsername)
                return true;

            return messageUsername != currentUsername;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}
