﻿using System.Globalization;

namespace TravelMate.Converters
{
    public class OwnMessageConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var username = value as string;
            var currentUsername = SecureStorage.GetAsync("username").Result;

            return username == currentUsername ? Colors.DodgerBlue : Colors.DarkGray;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}